
 <!-- Preloader Start-->
 <header>
    <!-- Header Start -->
    <div class="header-area ">
        <div class="main-header header-sticky" >
            <div class="container-fluid" >
                <div class=" menu-wrapper d-flex align-items-center justify-content-around"  >

                    <div class="header-left d-flex align-items-center">

                        <!-- Logo -->
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>"><h1>The Beverly Hills Luxury Boutique</h1></a>
                            
                        </div>
                        <!-- Main-menu -->
                        <div class="main-menu  d-none d-lg-block " >
                            
                            <nav>

                                <ul id="navigation">
                                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li> 
                                    
                                    
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>

                                    
                                    <?php if(session('user_id') != "" && session('user_type') != ""): ?>

                                    <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                                    <li><a href="<?php echo e(route('wishlist')); ?>">Wishlist</a></li>
                                    <?php else: ?>
                                    
                                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                    <?php endif; ?>
                                
                                


                                </ul>
                            </nav>
                        </div>   
                    </div>
                    

                    
                    <!-- Mobile Menu -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none">
                            
                            
                        </div>
                    </div>
                    
                </div>
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="header-left d-flex align-items-center">
                        <!-- Main-menu -->
                        <div class="main-menu  d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <?php $__currentLoopData = mainCategory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('category.show', ['category' => $category->id, 'categoryname' => strtolower($category->category_name)])); ?>"><?php echo e($category->category_name); ?></a>
                                            <?php if($category->subcategories->count() > 0): ?>
                                                <ul class="submenu">
                                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e(route('category.show', ['category' => $subcategory->id, 'categoryname' => strtolower($subcategory->category_name)])); ?>"><?php echo e($subcategory->category_name); ?></a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                
                            </nav>
                            
                            
                        </div>   
                    </div>
                </div>
               
            </div>
            
        </div>
        
        
    </div>
   
    <!-- Header End -->
</header>

<!-- header end -->


<?php /**PATH D:\xampp\htdocs\boutique\resources\views/home/header.blade.php ENDPATH**/ ?>