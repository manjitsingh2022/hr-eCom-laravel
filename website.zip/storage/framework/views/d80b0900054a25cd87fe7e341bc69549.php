

<?php $__env->startSection('content'); ?>

<div class="new-arrival">
    <div class="container">
     
      <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $bgColors = ['#f2f2f2', '#e6e6e6', '#d9d9d9', '#cccccc'];
                $bgColor = $bgColors[$index % count($bgColors)];
            ?>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
          <div class="single-new-arrival mb-50 text-center wow fadeInUp" data-wow-duration="1s" data-wow-delay=".1s">
            <div class="popular-img" >
                        
                <img src="<?php echo e(asset('product/' . $product->image)); ?>"alt="Product Image">

                <div class="favorit-items" style="display: grid;">
                    <form action="<?php echo e(route('wishlist.add', $product->id)); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="POST"> 
                        <input name="product_id" type="hidden" value="<?php echo e($product->id); ?>"> 
                        
                        <button type="submit" style=" border: none; background:none; cursor: pointer;" >
                            <img src="<?php echo e(asset('public/home/assets/img/gallery/favorit-card.png')); ?>" alt="Add to Wishlist" />
                        </button>
                        <div style=" align-items: center; gap: 3px; justify-content:flex-end; margin:2px;">
                            
                            <input name="quantity" type="number" value="1" min="1" class="small-input">
                        </div>
                    </form>
                </div>
                
                

                
                
            </div>
            <div class="popular-caption">
                <h3>
                    <a href="<?php echo e(route('contact')); ?>"><?php echo e($product->product_name); ?></a>
                    <p><?php echo e($product->description); ?></p>
                </h3>
              <div class="rating mb-10">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>
              <span> Rs. <?php echo e($product->price); ?></span>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12 text-center">
                <p class="card-text">No products available.</p>
            </div>
        <?php endif; ?>
      </div>
      <!-- Button -->
      
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.small-input {
    width: 40px;
    padding: 3px;
    background-color: #f1f1f1;
    border: 1px solid #ccc;
}

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\boutique\resources\views/home/product_details.blade.php ENDPATH**/ ?>