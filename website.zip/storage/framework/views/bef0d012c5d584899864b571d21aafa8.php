
<?php $__env->startSection('style'); ?>
<style type="text/css">
  .processing-icon {
    display: inline-block;
    position: relative;
  }

  .processing-icon .mdi {
    font-size: 24px;
    color: #e90000;
    /* Adjust the color as needed */
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- content-wrapper Start -->
<div class="row">
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-success ">
              <span class="mdi mdi-package-variant-closed icon-products"></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Products</h6>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-success">
              <span class="mdi mdi-cart icon-orders"></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Orders</h6>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-danger">
              <span class="mdi mdi-account-multiple icon-customers"></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Customers</h6>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-success ">
              <span class="mdi mdi-currency-usd icon-revenue"></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Revenue</h6>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-success ">
              <span class="mdi mdi-package icon-delivered "></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Delivered</h6>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <div class="row">
          <div class="col-9">
            <div class="d-flex align-items-center align-self-start">
              <h3 class="mb-0">

              </h3>
            </div>
          </div>
          <div class="col-3">
            <div class="icon icon-box-success ">
              <span class="mdi mdi-loading mdi-spin"></span>
            </div>
          </div>
        </div>
        <h6 class="text-muted font-weight-normal">Total Processing</h6>
      </div>
    </div>
  </div>



</div>
<div class="stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Category Details</h4>
      <p class="card-description"> Add class <code>.table-{color}</code>
      </p>
      <div class="table-responsive">
        <table class="table table-bordered table-contextual">
          <thead>
            <tr>
              <th>ID</th>
              <th>Parent ID</th>
              <th>Category Name</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-success">
              <td><?php echo e($category->id); ?></td>
              <td><?php echo e($category->parent_id); ?></td>
              <td><?php echo e($category->category_name); ?></td>
              <td><?php echo e($category->status); ?></td>
            </tr>
            <?php if($category->subcategories->count() > 0): ?>
            <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="table-danger">
              <td><?php echo e($subcategory->id); ?></td>
              <td><?php echo e($category->id); ?></td>
              <td><?php echo e($subcategory->category_name); ?></td>
              <td><?php echo e($subcategory->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>


<!-- content-wrapper ends -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\boutique\resources\views/admin/body.blade.php ENDPATH**/ ?>