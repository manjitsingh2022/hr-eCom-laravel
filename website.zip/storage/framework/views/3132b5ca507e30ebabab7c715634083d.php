<!-- resources/views/categories/create.blade.php -->


<?php $__env->startSection('style'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
  <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
  <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<h1>Create Category</h1>


<form action="<?php echo e(route('categories.store')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="form-group">
    <label for="category_name">Category Name</label>
    <input type="text" name="category_name" id="category_name" class="form-control" required>
  </div>

  <div class="form-group">
  <label for="parent_id">Parent Category</label>
  <select name="parent_id" id="parent_id" class="form-control">
    <option value="">Select Parent Category</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>





<div class="form-group" id="hidesubcategory">
  <label for="subcategory">Sub Category:</label>
  <select name="subcategory_id" id="subcategory" class="form-control" >
      <option value="">Select Sub Category</option>
  </select>
</div>
  


  <button type="submit" class="btn btn-primary">Create Category</button>
</form>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('scriptcontent'); ?>
<script>
  $(document).ready(function() {
    $('#parent_id').change(function(e) {
      var parentCategoryId = $(this).val();
      console.log(parentCategoryId, 'parentCategoryId');
      if (parentCategoryId) {
        $.ajax({
          url: '<?php echo e(route('getSubcategories')); ?>',
          type: 'post',
          dataType: 'json',
          data: {
            _token: '<?php echo e(csrf_token()); ?>',
            parentCategoryId: parentCategoryId
          },
          success: function(data) {
            console.log(data, 'datadatadata');
            $('#subcategory').empty().append('<option value="">Select Sub Category</option>');
            
            if (data.length > 0) {
              $.each(data, function(index, subcategory) {
                console.log(subcategory, index, 'subcategoryidex');
                $('#subcategory').append('<option value="' + subcategory.id + '">' + subcategory.category_name + '</option>');
              });
              $('#hidesubcategory').show();
            } else {
              $('#hidesubcategory').hide();
              $('#subcategory').empty();
            }
          },

          error: function(xhr, status, error) {
            console.log(xhr.responseText);
          }
        });
      } else {
        $('#subcategory').empty().append('<option value="">Select Sub Category</option>');
        $('#hidesubcategory').hide();
      }
    });
  });
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\boutique\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>