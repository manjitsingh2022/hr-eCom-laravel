

<?php $__env->startSection('style'); ?>
  <style type="text/css">
    table {
        width: 100%;
        border-collapse: collapse;
        border-bottom: 1px solid #ddd;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

   

    img.product-image {
        width: 100px;
        height: 100px;
        border-radius: 0;
    }

    .btn-delete {
        background-color: #dc3545;
        color: #fff;
    }

    .btn-delete:hover {
        background-color: #c82333;
    }

    .btn-edit {
        background-color: #28a745;
        color: #fff;
    }

    .btn-edit:hover {
        background-color: #218838;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 >All Products</h1>
<table >
   
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Description</th>
            <th>Image</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Discount Price</th>
            <th class="text-danger">Delete</th>
            <th>Edit</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->product_name); ?></td>
            <td><?php echo e($product->description); ?></td>
            <td><img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="Product Image" style="width: 100px; height: 100px; border-radius: 0;"></td>
            <td><?php echo e($product->catagory); ?></td>
            <td><?php echo e($product->quantity); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td><?php echo e($product->discount_price); ?></td>
            <td><a class="btn btn-danger" onclick="return confirm('Are you sure to delete this?')" href="<?php echo e(route('product.delete', ['id' => $product->id])); ?>">Delete</a></td>
            <td><a class="btn btn-success" href="<?php echo e(route('product.edit', ['id' => $product->id])); ?>">Edit</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\boutique\resources\views/admin/show_product.blade.php ENDPATH**/ ?>