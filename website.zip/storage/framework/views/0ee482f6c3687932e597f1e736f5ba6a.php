
<?php $__env->startSection('style'); ?>
    <style type="text/css">
        .div_center {
            text-align: center;
            padding-top: 40px;
        }
        .input_color{
            color:black;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <?php if(session()->has('message')): ?>

   <div class="alert alert-success">
    <button type="button" class="close"  data-dismiss='alert' aria-hidden="true">x</button>
    <?php echo e(session()->get('message')); ?>

    </div>
       
   <?php endif; ?>

<div class="div_center">
    <h2 class="h2_font">All Catagories</h2>

    <div class="container">
        <table class="table table-bordered table-hover mx-auto w-50 text-center">
            <thead>
                <tr>
                    <th>Category Name</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <tr>
            <td><?php echo e($category->category_name); ?></td>
                    <td>
                        <a onclick=" return confirm('Are you Sure to Delete this.')" class="btn btn-danger" href="<?php echo e(url('delete_catagory',$category->id)); ?>" >Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
    
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\boutique\resources\views/admin/category.blade.php ENDPATH**/ ?>